#! /bin/bash
# aqui utilizamos un contador para saber si, cuando lo buscamos con el coamdno ps y lo filtramos con grep, si es que existe va a sumarle 1 al contador
CONT=0
for i in $(ps -e | grep $1); do
	echo "existe el proceso"
	let CONT++

done
# si el contador de arriba no suma ninguno es por que no esta en ejecucion este proceso asi que mandamos un mail al root
if [ $CONT -eq 0 ]
then
	ls | mailx -s "El proceso del $1 no esta en ejecucion" /var/mail/root
fi
