#! /bin/bash

# la funcion mylog es la que se encarga de mandar el mail si es que salio bien o mal, con el horario de cuando se hizo
function mylog {
	TEXTO=$1
	FECHA_HORA=$(date +'%H:%M:%S')
	ls | mailx -s "($FECHA_HORA - $TEXTO)" /var/mail/root
}
# en el if con el -d vemos si el directorio que le pasemos como parametro existe el primer parametro es el directorio a backapear y el segundo parametro osea $3 es donde se va a guardar
if [ -d "$1" ] && [ -d "$3" ]
then	
	tar czf $1/_bkp_$(date +%Y%m%d).tar.gz $1
	tar xzf $1/_bkp_$(date +%Y%m%d).tar.gz -C $3
	mylog "haciendo backup del directorio $1"
else	
	mylog "no se pudo hacer el backup deñ directorio $1"
fi

if [ -d "$2" ] && [ -d "$3" ]  
then
	tar czf $2_bkp_$(date +%Y%m%d).tar.gz  $2
	tar xzf $2_bkp_$(date +%Y%m%d).tar.gz -C $3
	mylog "haciendo backup deñ directorio $2"
else
	mylog "no se pudo realizar el backup del directorio $2"
fi
